﻿# Running the tests  
The tests are built with mocha, to run them:  

1. Install mocha with the following command `npm install -g mocha`  
1. Install the dependencies with the following command `npm install` in the scripts directory
1. Make sure you are on the scripts directory and invoke mocha `mocha`  
